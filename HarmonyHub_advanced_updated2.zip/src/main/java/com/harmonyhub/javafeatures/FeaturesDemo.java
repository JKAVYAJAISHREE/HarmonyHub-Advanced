package com.harmonyhub.javafeatures;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.time.LocalDateTime;

/**
 * FeaturesDemo - a single-file collection of small examples demonstrating requested Java features.
 *
 * Note: Some features (String Templates, unnamed pattern variables using '_', newer stream gatherers)
 * are preview/very-new features in recent JDKs (JDK 21+ / 22 / 23). Those examples are included as
 * commented snippets and explanation so you can enable the appropriate --enable-preview flags to try them.
 *
 * The active (uncommented) code targets broadly supported modern JDK APIs (records, ScopedValue (JDK 21+),
 * interface private/default/static methods, varargs, defensive copying, etc.).
 */
public class FeaturesDemo {

    // ------------------------------ this() vs this ------------------------------
    // Demonstrates constructor chaining using this(...), vs using this to reference the current object.
    public static final class Person {
        private final String name;
        private final int age;

        public Person(String name) {
            this(name, 0); // calls this(...) -> constructor chaining
        }

        public Person(String name, int age) {
            this.name = name; // this.field reference to current object's field
            this.age = age;
        }

        public String toString() {
            return "Person{name='" + name + "', age=" + age + "}";
        }
    }

    // ------------------------------ Varargs ------------------------------
    public static int sumInts(int... numbers) {
        int s = 0;
        for (int n : numbers) s += n;
        return s;
    }

    // ------------------------------ super() vs super ------------------------------
    static class Animal {
        protected final String species;
        public Animal(String species) { this.species = species; }
        public String identity() { return "Animal<" + species + ">"; }
    }
    static class Dog extends Animal {
        public Dog() { super("Canis familiaris"); } // calls super(...)
        @Override
        public String identity() { return "Dog extends " + super.identity(); } // super.method() to call parent method
    }

    // ------------------------------ Arrays ------------------------------
    public static <T> T[] copyArray(T[] arr) {
        // simple defensive copy using Arrays.copyOf
        return Arrays.copyOf(arr, arr.length);
    }

    // ------------------------------ Defensive copying ------------------------------
    public static final class ImmutablePlaylist {
        private final String[] tracks; // internal array must be protected

        public ImmutablePlaylist(String[] tracks) {
            // defensive copy on construction
            this.tracks = (tracks == null) ? new String[0] : Arrays.copyOf(tracks, tracks.length);
        }

        public String[] getTracks() {
            // defensive copy on access
            return Arrays.copyOf(tracks, tracks.length);
        }
    }

    // ------------------------------ Interface private/default/static methods ------------------------------
    public interface Recommender {
        // public abstract method
        List<String> recommend(String user);

        // default method - provides a fallback implementation
        default List<String> recommendTop3(String user) {
            return recommend(user).stream().limit(3).collect(Collectors.toList());
        }

        // private helper method (since Java 9)
        private List<String> fromSource(String src) {
            // pretend to consult a source
            return List.of(src + "-a", src + "-b", src + "-c");
        }

        // static method on the interface (since Java 8)
        static Recommender createDemo() {
            return user -> List.of("song1", "song2", "song3", "song4");
        }
    }

    // ------------------------------ "final" vs "effectively final" ------------------------------
    public static void demonstrateFinalEffectivelyFinal() {
        final int a = 5; // declared final - cannot be reassigned
        int b = 7;       // not declared final
        Runnable r1 = () -> {
            // 'a' can be used directly - it's final
            System.out.println("a = " + a);
            // 'b' can also be used in the lambda if it is *effectively final* (not reassigned after capture)
            System.out.println("b = " + b);
        };
        r1.run();
        // if we reassign 'b' here (uncommenting the next line), the lambda capture would fail compilation:
        // b = 8; // would make 'b' not effectively final
    }

    // ------------------------------ Unnamed variables / patterns (_) ------------------------------
    /*
     * Modern Java (as of recent preview features) introduced the underscore '_' as a discard variable in pattern matching.
     * Example (preview syntax, commented out because it requires --enable-preview and exact JDK support):
     *
     *   // instanceof pattern with unnamed binding (preview)
     *   // if (obj instanceof Point(_, int y)) { ... } // the '_' discards the matched X coordinate
     *
     * In regular code you can ignore values by not naming them; using '_' as an identifier is generally discouraged/illegal in some versions.
     */

    // ------------------------------ Stream "gatherers" (Java 22) ------------------------------
    // Newer JDKs introduced richer collecting APIs. If your JDK supports "gathering" or specialized collectors, prefer them.
    // Portable example using existing Collectors to group + combine (works on older JDKs):
    public static Map<Integer, List<String>> groupByLength(Stream<String> s) {
        return s.collect(Collectors.groupingBy(String::length));
    }

    // Example that mimics "gathering" by collecting multiple downstream results in one pass:
    public static <T> Map<Integer, Integer> countByLength(Stream<String> s) {
        return s.collect(Collectors.groupingBy(String::length, Collectors.summingInt(e -> 1)));
    }

    // ------------------------------ String templates (Java 23 preview) ------------------------------
    /*
     * String templates are a preview feature in recent JDKs. Example commented snippet (requires --enable-preview):
     *
     *   // preview syntax
     *   // String name = "Kavya";
     *   // String message = STR."Hello \{name}, today is \{java.time.LocalDate.now()}.";
     *
     * For portability, use String.format or plain concatenation if you don't enable preview features.
     */

    // ------------------------------ Scoped Values (Java 21) ------------------------------
    // ScopedValue (JDK 21+) example. This API replaces ThreadLocal for some use-cases and works with structured concurrency.
    public static void scopedValueExample() {
        try {
            // Use reflection to avoid compile error on older JDKs when this file is compiled on older releases.
            Class<?> svClass = Class.forName("java.lang.ScopedValue");
            // If present, demonstrate conceptually:
            System.out.println("ScopedValue present in this JDK: " + svClass.getName());
        } catch (ClassNotFoundException e) {
            System.out.println("ScopedValue API not available on this JDK runtime.");
        }
    }

    // ------------------------------ Small demo main ------------------------------
    public static void main(String[] args) {
        System.out.println("--- this() vs this ---");
        System.out.println(new Person("Alice"));
        System.out.println(new Person("Bob", 30));

        System.out.println("--- Varargs ---");
        System.out.println("sumInts(1,2,3) = " + sumInts(1,2,3));

        System.out.println("--- super() vs super ---");
        System.out.println(new Dog().identity());

        System.out.println("--- Arrays + defensive copying ---");
        String[] arr = new String[]{"a","b"};
        ImmutablePlaylist p = new ImmutablePlaylist(arr);
        arr[0] = "z"; // caller mutates original array
        System.out.println("Playlist tracks after external mutation: " + Arrays.toString(p.getTracks()));

        System.out.println("--- Interface default/private/static methods ---");
        Recommender r = Recommender.createDemo();
        System.out.println("Top3: " + r.recommendTop3("u"));

        System.out.println("--- final vs effectively final ---");
        demonstrateFinalEffectivelyFinal();

        System.out.println("--- Streams grouping examples ---");
        System.out.println(groupByLength(Stream.of("one","two","three","four")));
        System.out.println(countByLength(Stream.of("one","two","three","four")));

        System.out.println("--- ScopedValue check ---");
        scopedValueExample();
    }
}
