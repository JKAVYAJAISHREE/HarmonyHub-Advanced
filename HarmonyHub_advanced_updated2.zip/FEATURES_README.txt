Java language features additions - notes

Files added:
  - src/main/java/com/harmonyhub/javafeatures/FeaturesDemo.java

What the file contains:
  - constructor chaining (this(...) ) and 'this' field access examples
  - varargs example (sumInts)
  - super(...) constructor calls and super.method() usage
  - arrays + defensive copying with ImmutablePlaylist
  - interface private/default/static method examples (Recommender)
  - explanation + example of final vs effectively final in lambdas
  - commented explanations for preview features: unnamed (_) pattern variables, string templates (JDK 23 preview)
  - Stream grouping/gathering examples using Collectors.groupingBy and summingInt
  - ScopedValue detection example (uses reflection to remain compatible with older JDKs)

Notes about preview features:
  - To try commented preview snippets you must compile+run with the correct JDK and --enable-preview flags.
  - I included comments with example syntax; I did not add active preview-only syntax to avoid breaking compilation on non-preview JDKs.

To run quick demo (if you have a Java toolchain):
  javac -d out src/main/java/com/harmonyhub/javafeatures/FeaturesDemo.java
  java -cp out com.harmonyhub.javafeatures.FeaturesDemo
