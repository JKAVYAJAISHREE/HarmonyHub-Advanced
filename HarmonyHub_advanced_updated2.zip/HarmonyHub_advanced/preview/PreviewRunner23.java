/*
 Preview runner for JDK23 preview examples.
 Compile with: javac --enable-preview --release 23 -d out_preview23 preview/*.java
 Run with: java --enable-preview -cp out_preview23 PreviewRunner23
 */
public class PreviewRunner23 {
    public static void main(String[] args) {
        System.out.println("Preview runner (JDK23) - examples are in preview/*.java");
    }
}
