Preview examples (require a JDK that supports the preview and --enable-preview).

Files:
 - PreviewCtor.java (JEP 447: Statements before super) - compile with --enable-preview --release 22
 - StreamGatherDemo.java (JEP 461: Stream gatherers) - preview JDK22
 - ScopedValueDemo.java (JEP 481: Scoped Values) - preview JDK23
 - StringTemplateDemoPreview.java - preview (if available)

They are examples and won't compile under standard -release 21.
