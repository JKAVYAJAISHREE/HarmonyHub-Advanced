/*
 Scoped values are a preview feature in JDK23 (JEP 481). This file is illustrative.
 Compile with --enable-preview --release 23
 */
public class ScopedValueDemo {
    public static void main(String[] args) {
        System.out.println("ScopedValue demo (preview) - compile with --enable-preview --release 23");
    }
}
