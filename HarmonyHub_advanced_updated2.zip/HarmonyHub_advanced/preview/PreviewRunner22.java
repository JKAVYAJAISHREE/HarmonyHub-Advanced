/*
 Preview runner for JDK22 preview examples.
 Compile with: javac --enable-preview --release 22 -d out_preview preview/*.java
 Run with: java --enable-preview -cp out_preview PreviewRunner22
 */
public class PreviewRunner22 {
    public static void main(String[] args) {
        System.out.println("Preview runner (JDK22) - examples are in preview/*.java");
    }
}
