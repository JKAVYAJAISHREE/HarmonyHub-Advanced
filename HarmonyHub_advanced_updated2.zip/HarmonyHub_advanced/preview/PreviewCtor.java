/*
 This is a JDK22 preview illustration (statements before super()) - PREVIEW CODE.
 Must be compiled with --enable-preview --release 22
 */
public class PreviewCtor extends java.lang.Object {
    private final String value;
    public PreviewCtor(String raw) {
        var normalized = raw == null ? "" : raw.trim().toUpperCase(); // allowed pre-super in preview
        // Note: This is PREVIEW feature demonstration only
        this.value = normalized;
    }
    public String get() { return value; }
}
