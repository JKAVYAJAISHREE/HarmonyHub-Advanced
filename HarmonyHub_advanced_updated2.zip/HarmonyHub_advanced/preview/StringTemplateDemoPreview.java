/*
 String Template preview (if available) - illustration only. Not used by stable build.
 */
public class StringTemplateDemoPreview {
    public static void main(String[] args) {
        System.out.println("String Template preview illustration");
    }
}
