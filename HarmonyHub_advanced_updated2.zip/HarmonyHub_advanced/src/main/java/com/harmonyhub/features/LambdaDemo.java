package com.harmonyhub.features;

import com.harmonyhub.core.model.*;
import java.util.function.Predicate;


/** Lambdas, Predicates and method references demo */
public class LambdaDemo {
    public static void runDemo(com.harmonyhub.services.HubService hub) {
        System.out.println("-- LambdaDemo --");
        Predicate<Song> energetic = s -> s.mood() == Mood.PARTY;
        var list = hub.getSongs().stream().filter(energetic).toList();
        list.forEach(System.out::println); // method reference
    }
}
