package com.harmonyhub.features;

import com.harmonyhub.core.model.*;

/**
 * Demonstrates switch expression + pattern matching and unnamed pattern '_'
 */
public class PatternSwitchDemo {
    public static String describe(MusicAsset a) {
        return switch (a) {
            case Song s -> "Song: " + s.title() + " (" + s.genre() + ")";
            case Podcast p -> "Podcast: " + p.title();
            case LiveSet l -> "LiveSet (offline)"; // Use a valid identifier (e.g., 'l')
            default -> "Unknown";
        };
    }
}
