package com.harmonyhub.app;

import com.harmonyhub.core.model.*;
import com.harmonyhub.services.*;
import com.harmonyhub.features.*;
import com.harmonyhub.player.VirtualPlayer;

import java.time.LocalDateTime;
import java.util.List;

public class HarmonyHubApp {
    public static void main(String[] args) throws Exception {
        System.out.println("HarmonyHub: advanced demo (stable features)");
        HubService hub = new HubService();

        UserProfile alice = new UserProfile("alice@example.com", "Alice");
        UserProfile bob = new UserProfile("bob@example.com", "Bob");

        Song s1 = new Song(new SongId("S-001"), "Mellow Breeze", Genre.JAZZ, Mood.CHILL, 210, "acoustic","instrumental");
        Song s2 = new Song(new SongId("S-002"), "Beat Drop", Genre.ELECTRONIC, Mood.PARTY, 180);
        Song s3 = new Song(new SongId("S-003"), "Focus Flow", Genre.CLASSICAL, Mood.FOCUS, 300);
        Podcast p1 = new Podcast(new SongId("P-001"), "CoderTalk", 12);
        LiveSet l1 = new LiveSet(new SongId("L-001"), "Live at Harmony");

        hub.addAsset(s1, s2, s3, p1, l1);

        PlaylistService pls = new PlaylistService(hub);
        var pl = pls.createPlaylist(alice, "Alice Chill", s1, s3);

        RecommendationService rec = new RecommendationService(hub);
        List<Song> chill = rec.recommendByMood(Mood.CHILL);
        System.out.println("Recommendations (CHILL): " + chill);

        // pattern matching + switch
        System.out.println(PatternSwitchDemo.describe(s2));

        // lambdas & method refs
        LambdaDemo.runDemo(hub);

        // virtual thread player demo
        VirtualPlayer vp = new VirtualPlayer();
        vp.playAsync(s2, bob.name());

        // wait briefly for virtual thread prints
        Thread.sleep(250);

        System.out.println("History: " + hub.recentPlays());
        System.out.println("Demo finished.");
    }
}
