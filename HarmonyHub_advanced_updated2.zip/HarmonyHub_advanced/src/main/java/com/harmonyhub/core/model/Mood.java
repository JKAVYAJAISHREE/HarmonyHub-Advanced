package com.harmonyhub.core.model;

/**
 * Enum representing the mood of a song.
 */
public enum Mood {
    HAPPY, SAD, RELAXED, EXCITED, PARTY, CHILL, FOCUS  // Add missing values here
}
