package com.harmonyhub.core.model;

import java.util.Objects;

/** Immutable user profile */
public final class UserProfile {
    private final String email;
    private final String name;

    public UserProfile(String email, String name) {
        this.email = Objects.requireNonNull(email);
        this.name = Objects.requireNonNull(name);
    }

    public String email() { return email; }
    public String name() { return name; }

    @Override public String toString() { return name + " <" + email + ">"; }
}
