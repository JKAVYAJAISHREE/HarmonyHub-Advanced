package com.harmonyhub.core.model;

/** LiveSet - not streamable (demonstrates differing behavior) */
public final class LiveSet implements MusicAsset {
    private final SongId id;
    private final String title;

    public LiveSet(SongId id, String title) { this.id = id; this.title = title; }

    @Override public SongId id() { return id; }
    @Override public String title() { return title; }
    @Override public boolean streamable() { return false; }

    @Override public String toString() { return "LiveSet[" + title + "]"; }
}
