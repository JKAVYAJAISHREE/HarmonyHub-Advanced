package com.harmonyhub.core.model;

/** Checked exception example */
public class PlaybackException extends Exception {
    public PlaybackException(String msg) { super(msg); }
}
