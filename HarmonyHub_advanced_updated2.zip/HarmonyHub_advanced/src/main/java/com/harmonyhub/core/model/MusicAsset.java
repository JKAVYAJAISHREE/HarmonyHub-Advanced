// package com.harmonyhub.core.model;

// /**
//  * A class representing a song, implementing the MusicAsset interface.
//  */
// public final class Song implements MusicAsset {
//     private final SongId id;
//     private final String title;
//     private final boolean streamable;

//     // Constructor for Song
//     public Song(SongId id, String title, boolean streamable) {
//         this.id = id;
//         this.title = title;
//         this.streamable = streamable;
//     }

//     @Override
//     public SongId id() {
//         return this.id;
//     }

//     @Override
//     public String title() {
//         return this.title;
//     }

//     @Override
//     public boolean streamable() {
//         return this.streamable;
//     }
// }


package com.harmonyhub.core.model;

/**
 * Sealed interface for music assets, defining common properties and methods
 * for all types of music-related assets.
 */
public sealed interface MusicAsset permits Song, Podcast, LiveSet, MediaItem {

    // Method to return the unique identifier for the music asset
    SongId id();

    // Method to return the title of the music asset
    String title();

    // Method to check if the music asset is streamable
    boolean streamable();
}

