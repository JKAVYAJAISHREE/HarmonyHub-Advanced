// package com.harmonyhub.core.model;

// /**
//  * Abstract base class to show super() and shared logic.
//  */
// public abstract class MediaItem implements MusicAsset {
//     private final SongId id;
//     private final String title;

//     public MediaItem(SongId id, String title) {
//         this.id = id;
//         this.title = title;
//     }

//     @Override public SongId id() { return id; }
//     @Override public String title() { return title; }

//     protected String baseInfo() {
//         return "MediaItem[" + id + ":" + title + "]";
//     }
// }

package com.harmonyhub.core.model;

/**
 * A class representing a media item, implementing the MusicAsset interface.
 */
public final class MediaItem implements MusicAsset {
    private final SongId id;
    private final String title;

    // Constructor for MediaItem
    public MediaItem(SongId id, String title) {
        this.id = id;
        this.title = title;
    }

    @Override
    public SongId id() {
        return this.id;
    }

    @Override
    public String title() {
        return this.title;
    }

    @Override
    public boolean streamable() {
        return true; // Assuming MediaItem is always streamable
    }
}
