// package com.harmonyhub.core.model;

// import com.harmonyhub.core.interfaces.Playable;
// import java.util.Arrays;
// import java.util.StringJoiner;

// // Song class implementing MusicAsset
// public final class Song implements MusicAsset {
//     private final SongId id;
//     private final String title;
//     private final boolean streamable;

//     public Song(SongId id, String title, boolean streamable) {
//         this.id = id;
//         this.title = title;
//         this.streamable = streamable;
//     }

//     @Override
//     public SongId id() {
//         return id;
//     }

//     @Override
//     public String title() {
//         return title;
//     }

//     @Override
//     public boolean streamable() {
//         return streamable;
//     }
// }
package com.harmonyhub.core.model;

/**
 * A class representing a song, implementing the MusicAsset interface.
 */
public final class Song implements MusicAsset {
    private final SongId id;
    private final String title;
    private final boolean streamable;
    private final Mood mood;
    private final Genre genre;
    private final int duration; // duration in seconds
    private final String type;  // type of song (e.g., "acoustic", "instrumental")

    // Updated constructor to include duration and type
    public Song(SongId id, String title, Genre genre, Mood mood, int duration, String... type) {
        this.id = id;
        this.title = title;
        this.genre = genre;
        this.mood = mood;
        this.streamable = true;  // Assuming all songs are streamable
        this.duration = duration;
        this.type = (type.length > 0) ? type[0] : "unknown";  // Default type if not provided
    }

    @Override
    public SongId id() {
        return this.id;
    }

    @Override
    public String title() {
        return this.title;
    }

    @Override
    public boolean streamable() {
        return this.streamable;
    }

    public Mood mood() {
        return this.mood;
    }

    public Genre genre() {
        return this.genre;
    }

    public int duration() {
        return this.duration;
    }

    public String type() {
        return this.type;
    }
}

