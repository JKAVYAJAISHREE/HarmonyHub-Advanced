// package com.harmonyhub.core.model;

// /** Simple Podcast asset */
// public final class Podcast implements MusicAsset {
//     private final SongId id;
//     private final String title;
//     private final int episode;

//     public Podcast(SongId id, String title, int episode) {
//         this.id = id;
//         this.title = title;
//         this.episode = episode;
//     }

//     @Override
//     public SongId id() {
//         return id;
//     }

//     @Override
//     public String title() {
//         return title;
//     }

//     @Override
//     public boolean streamable() {
//         return true;
//     }

//     @Override
//     public String toString() {
//         return "Podcast[" + title + " #" + episode + "]";
//     }
// }

package com.harmonyhub.core.model;

public final class Podcast implements MusicAsset {
    private final SongId id;
    private final String title;
    private final int episode;

    public Podcast(SongId id, String title, int episode) {
        this.id = id;
        this.title = title;
        this.episode = episode;
    }

    @Override public SongId id() { return id; }
    @Override public String title() { return title; }
    @Override public boolean streamable() { return true; }

    @Override public String toString() { return "Podcast[" + title + " #" + episode + "]"; }
}
