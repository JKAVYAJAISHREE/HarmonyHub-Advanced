package com.harmonyhub.core.model;

import java.time.LocalDateTime;

/** Record demonstrating Java records (immutable data carrier) */
public record PlayEvent(SongId id, String user, LocalDateTime playedAt) {}
