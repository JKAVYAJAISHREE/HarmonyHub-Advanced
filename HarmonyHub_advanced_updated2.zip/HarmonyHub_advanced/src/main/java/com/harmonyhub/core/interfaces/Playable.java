package com.harmonyhub.core.interfaces;

import com.harmonyhub.core.model.MusicAsset;
import com.harmonyhub.core.model.MusicAsset;
import com.harmonyhub.core.model.SongId;
import com.harmonyhub.core.model.Mood;
import com.harmonyhub.core.model.Genre;


/**
 * Playable interface demonstrates default/private/static methods.
 */
public interface Playable {
    void play(String user) throws Exception;

    default String nowPlaying(String user, MusicAsset asset) {
        return buildNowPlaying(user, asset);
    }

    private static String buildNowPlaying(String user, MusicAsset asset) {
        return String.format("%s is listening to '%s' (id=%s)", user, asset.title(), asset.id());
    }

    static void requireUser(String user) {
        if (user == null || user.isBlank()) throw new IllegalArgumentException("user required");
    }
}
