package com.harmonyhub.core.model;

import java.util.Arrays;
import java.util.Objects;

/**
 * Immutable SongId demonstrating defensive copying.
 */
public final class SongId {
    private final byte[] bytes;

    public SongId(String id) {
        Objects.requireNonNull(id);
        this.bytes = id.getBytes(); // defensive: copy from String
    }

    public String asString() { return new String(bytes); }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SongId)) return false;
        SongId other = (SongId) o;
        return Arrays.equals(bytes, other.bytes);
    }

    @Override
    public int hashCode() { return Arrays.hashCode(bytes); }

    @Override
    public String toString() { return asString(); }
}
