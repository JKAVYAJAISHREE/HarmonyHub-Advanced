// package com.harmonyhub.core.model;

// import java.util.List;

// public class Playlist {
//     private String name;
//     private List<Song> songs;

//     public Playlist(String name, List<Song> songs) {
//         this.name = name;
//         this.songs = songs;
//     }

//     // Getters and setters
//     public String getName() {
//         return name;
//     }

//     public void setName(String name) {
//         this.name = name;
//     }

//     public List<Song> getSongs() {
//         return songs;
//     }

//     public void setSongs(List<Song> songs) {
//         this.songs = songs;
//     }
// }

package com.harmonyhub.core.model;

import java.util.ArrayList;
import java.util.List;

public class Playlist {
    private String name;
    private List<MusicAsset> items; // List of MusicAsset (can hold Song, Podcast, etc.)

    public Playlist(String name, MusicAsset... items) {
        this.name = name;
        this.items = new ArrayList<>();
        if (items != null) {
            for (MusicAsset item : items) {
                this.items.add(item);
            }
        }
    }

    // Add method to add MusicAsset
    public void add(MusicAsset asset) {
        if (asset != null) {
            items.add(asset);
        }
    }

    // Getter for items
    public List<MusicAsset> getItems() {
        return items;
    }
}
