package com.harmonyhub.core.exceptions;

public class InvalidPlaylistException extends Exception {
    // Constructor with a message
    public InvalidPlaylistException(String message) {
        super(message);
    }

    // Constructor with both message and cause
    public InvalidPlaylistException(String message, Throwable cause) {
        super(message, cause);
    }
}
