package com.harmonyhub.core.model;

/**
 * Enum representing the genre of a song.
 */
public enum Genre {
    POP, ROCK, JAZZ, CLASSICAL, ELECTRONIC // Add missing value ELECTRONIC here
}
