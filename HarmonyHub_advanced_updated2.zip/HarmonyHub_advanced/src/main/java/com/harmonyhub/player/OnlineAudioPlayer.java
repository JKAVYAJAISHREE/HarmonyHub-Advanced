package com.harmonyhub.player;

import com.harmonyhub.core.model.MusicAsset;

public final class OnlineAudioPlayer extends AudioPlayer {
    @Override public void play(MusicAsset asset, String user) {
        System.out.println("[OnlinePlayer] streaming " + asset.title() + " for " + user);
    }
}
