package com.harmonyhub.player;

import com.harmonyhub.core.model.MusicAsset;

/**
 * Demonstrates virtual threads (Java 21+).
 */
public final class VirtualPlayer extends AudioPlayer {
    @Override public void play(MusicAsset asset, String user) {
        System.out.println("[VirtualPlayer] " + user + " -> " + asset.title());
    }

    public void playAsync(MusicAsset asset, String user) {
        Thread.ofVirtual().start(() -> {
            try { Thread.sleep(60); } catch (InterruptedException ignored) {}
            play(asset, user);
            System.out.println("[VirtualPlayer] finished " + asset.title());
        });
    }
}
