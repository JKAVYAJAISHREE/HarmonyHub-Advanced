package com.harmonyhub.player;

import com.harmonyhub.core.model.MusicAsset;

public final class LocalAudioPlayer extends AudioPlayer {
    @Override public void play(MusicAsset asset, String user) {
        System.out.println("[LocalPlayer] " + user + " plays " + asset.title());
    }
}
