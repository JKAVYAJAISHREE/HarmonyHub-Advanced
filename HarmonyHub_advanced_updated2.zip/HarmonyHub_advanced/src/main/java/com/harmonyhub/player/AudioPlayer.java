package com.harmonyhub.player;

import com.harmonyhub.core.model.MusicAsset;

/**
 * Sealed player hierarchy.
 */
public sealed abstract class AudioPlayer permits LocalAudioPlayer, OnlineAudioPlayer, VirtualPlayer {
    public abstract void play(MusicAsset asset, String user);
}
