package com.harmonyhub.services;

import com.harmonyhub.core.model.*;
import com.harmonyhub.core.model.SongId;
import com.harmonyhub.core.model.PlayEvent;
import com.harmonyhub.core.model.MusicAsset;




import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import com.harmonyhub.core.model.Playlist;

/**
 * Central hub storing assets and history.
 */
public class HubService {
    private final List<MusicAsset> assets = new ArrayList<>();
    private final List<PlayEvent> history = new ArrayList<>();
    private final Map<UserProfile, List<Playlist>> playlists = new HashMap<>();

    public void addAsset(MusicAsset... items) {
        assets.addAll(Arrays.asList(items));
    }

    public MusicAsset[] snapshot() { return assets.toArray(new MusicAsset[0]); }

    public List<Song> getSongs() {
        return assets.stream().filter(Song.class::isInstance).map(Song.class::cast).collect(Collectors.toList());
    }

    public void recordPlay(SongId id, String user, LocalDateTime at) {
        history.add(new PlayEvent(id, user, at));
    }

    public List<PlayEvent> recentPlays() { return List.copyOf(history); }

    public Optional<MusicAsset> findById(SongId id) {
        return assets.stream().filter(a -> a.id().equals(id)).findFirst();
    }

    public void registerPlaylist(UserProfile owner, Playlist pl) {
        playlists.computeIfAbsent(owner, k -> new ArrayList<>()).add(pl);
    }
}
