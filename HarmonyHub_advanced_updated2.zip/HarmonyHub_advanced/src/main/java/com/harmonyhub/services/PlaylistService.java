package com.harmonyhub.services;

import com.harmonyhub.core.model.*;
import com.harmonyhub.core.exceptions.InvalidPlaylistException;

/**
 * Playlist creation and management.
 */
public class PlaylistService {
    private final HubService hub;

    public PlaylistService(HubService hub) { 
        this.hub = hub; 
    }

    public Playlist createPlaylist(UserProfile owner, String name, MusicAsset... items) {
        // Create new playlist with name and items
        Playlist p = new Playlist(name, items);
        // Register the playlist
        hub.registerPlaylist(owner, p);
        return p;
    }

    public void addToPlaylist(Playlist pl, MusicAsset asset) throws InvalidPlaylistException {
        if (pl == null) {
            throw new InvalidPlaylistException("Playlist missing");
        }
        // Add asset to playlist
        pl.add(asset);
    }
}
