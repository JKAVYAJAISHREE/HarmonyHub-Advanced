package com.harmonyhub.services;

import com.harmonyhub.core.model.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Recommendation logic using predicates and method references.
 */
public class RecommendationService {
    private final HubService hub;

    public RecommendationService(HubService hub) { this.hub = hub; }

    public List<Song> recommendByMood(Mood mood) {
        return hub.getSongs().stream()
                .filter(s -> s.mood() == mood)
                .collect(Collectors.toList());
    }
}
