# HarmonyHub - Advanced Java 21/22/23 Demo

This project demonstrates Java language features across Java 21 (LTS), Java 22, and Java 23.
It contains:
 - Stable code (runs on Java 21+)
 - Optional preview-feature examples (in `preview/`) that require `--enable-preview` and specific JDK release flags.

## Build & Run (stable)
Requires JDK 21+ and Maven.

Compile:
```
mvn -f pom.xml clean package
```

Run:
```
java -cp target/harmonyhub-1.0.0.jar com.harmonyhub.app.HarmonyHubApp
```

Or run from VS Code (Java extension) by opening the folder.

## Preview features (optional)
If you want to try preview features (JDK 22/23), use a matching JDK and pass `--enable-preview`.

Example compile (JDK 22 preview):
```
javac --enable-preview --release 22 -d out_preview $(find preview -name '*.java')
java --enable-preview -cp out_preview PreviewRunner22
```

Example compile (JDK 23 preview):
```
javac --enable-preview --release 23 -d out_preview23 $(find preview -name '*.java')
java --enable-preview -cp out_preview23 PreviewRunner23
```

Preview files are kept under `preview/` and clearly labeled.

Enjoy — the code is original and crafted for this demo.
